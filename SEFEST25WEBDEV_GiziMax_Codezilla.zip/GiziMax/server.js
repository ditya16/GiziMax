require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors({ origin: '*' })); // Bisa disesuaikan dengan domain frontend
app.use(express.json());

// Koneksi ke MongoDB
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/gizimax', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('✅ MongoDB Connected'))
  .catch(err => console.error('❌ MongoDB Connection Error:', err));

// Skema Chat
const chatSchema = new mongoose.Schema({
    userMessage: { type: String, required: true },
    botResponse: { type: String, required: true },
    timestamp: { type: Date, default: Date.now }
});

const Chat = mongoose.model('Chat', chatSchema);

// API untuk Menyimpan Chat dan Memberikan Respons
app.post('/api/chat', async (req, res) => {
    try {
        console.log("📩 Request Diterima:", req.body);

        const { userMessage } = req.body;
        if (!userMessage) {
            return res.status(400).json({ error: '❌ Pesan tidak boleh kosong' });
        }

        // Simulasi respons bot (bisa diganti dengan AI/NLP)
        const botResponse = `Terima kasih atas pertanyaan Anda tentang "${userMessage}". Kami akan segera membantu Anda.`;

        const newChat = new Chat({ userMessage, botResponse });
        await newChat.save();
        
        console.log("✅ Chat berhasil disimpan:", newChat);
        res.status(201).json({ botResponse });
    } catch (error) {
        console.error("❌ Error saat menyimpan chat:", error);
        res.status(500).json({ error: '❌ Gagal menyimpan chat' });
    }
});

// API untuk Mengambil Semua Chat
app.get('/api/chat', async (req, res) => {
    try {
        const chats = await Chat.find().sort({ timestamp: -1 });
        res.status(200).json(chats);
    } catch (error) {
        console.error("❌ Error saat mengambil chat:", error);
        res.status(500).json({ error: '❌ Gagal mengambil chat' });
    }
});

// Jalankan Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server berjalan di http://localhost:${PORT}`);
});

