document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("loginForm");
    const signupForm = document.getElementById("signupForm");

    if (loginForm) {
        loginForm.addEventListener("submit", (event) => {
            event.preventDefault();
            alert("Login berhasil!");
            window.location.href = "gizimaxafterlogin/index.html"; // Redirect ke halaman lain setelah login
        });
    }

    if (signupForm) {
        signupForm.addEventListener("submit", (event) => {
            event.preventDefault();
            alert("Pendaftaran berhasil! Silakan login.");
            window.location.href = "login.html"; // Redirect ke halaman login setelah signup
        });
    }
});
