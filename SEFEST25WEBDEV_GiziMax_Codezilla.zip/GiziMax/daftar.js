const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = 4000;

// Middleware
app.use(cors());
app.use(express.json()); // Gunakan express.json() agar bisa menangani request JSON

// Koneksi ke MongoDB
mongoose.connect('mongodb://localhost:27017/gizi_max', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB', err));

// Schema dan Model untuk User
const userSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String
});

const User = mongoose.model('User', userSchema);

// Endpoint untuk Signup (via script.js)
app.post('/signup', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        
        // Periksa apakah email sudah terdaftar
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "Email sudah digunakan!" });
        }
        
        // Simpan user baru ke database
        const newUser = new User({ username, email, password });
        await newUser.save();

        res.status(201).json({ message: "Pendaftaran berhasil!" });
    } catch (error) {
        res.status(500).json({ message: "Terjadi kesalahan!" });
    }
});

// Jalankan server
app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
});
